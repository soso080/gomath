<h1 align="center">
gomaths
</h1>


<h2 align="center">
How to install 
</h2>

```python
pip install gomath
```

<h2 align="center">
Exemple
</h2>

```python
from gomath import *

calc = gomath.Calcul()



a = calc.pair(1, 2, 3, 4, 5, 6)

b = calc.multiplication(4, 2)

c = calc.AreaSquarre(2, 4)



print(a, b, c)
```